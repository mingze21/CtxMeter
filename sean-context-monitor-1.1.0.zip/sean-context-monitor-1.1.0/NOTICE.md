# SEAN Context Monitor — Notices

SEAN Context Monitor is an independently maintained customization for SEAN.
The direct modification baseline for product version 1.1.0 (maintenance
identifier 1.1.0+sean.1) is the local build 1.0.0+sean.2, which inherited 1.0.0+sean.1,
3.1.7+sean.context.1, 3.1.7+sean.topbar.1 and the following MIT-licensed upstream release:

- JiaYang-BUAA/Codex-Desktop-Usage-Monitor-Windows v3.1.7:
  https://github.com/JiaYang-BUAA/Codex-Desktop-Usage-Monitor-Windows

Copyright (c) 2026 Codex Usage Monitor contributors.
The upstream copyright and MIT license are retained in LICENSE. Product naming
and interface changes do not remove that attribution or imply ownership of
the upstream contributions. The compact context meter uses an original SEAN
design; no Nudge source code, artwork or logo is bundled.

The compatibility state directory and internal identifiers continue to use
CodexUsageMonitor / codex-usage-monitor to preserve existing settings and
Windows DPAPI credentials. The runtime does not load the upstream updater.

Codex Usage Monitor for Windows is derivative software based on runtime-injection ideas from:

- Fei-Away/Codex-Dream-Skin: https://github.com/Fei-Away/Codex-Dream-Skin
- tree0519/Codex-Dream-Skin-Forge: https://github.com/tree0519/Codex-Dream-Skin-Forge

The distributed package contains no bundled themes, character artwork, Codex binaries, Node.js runtime, credentials, or user configuration.

Reset probability data is retrieved at runtime from the public API of the MIT-licensed open-source project Codex Reset Observatory:

- gussuri/codex-reset-observatory: https://github.com/gussuri/codex-reset-observatory

No Codex Reset Observatory source code or prediction dataset is bundled in this package.

Codex and OpenAI are trademarks of their respective owners. This project is unofficial and is not affiliated with, sponsored by, or endorsed by OpenAI.
